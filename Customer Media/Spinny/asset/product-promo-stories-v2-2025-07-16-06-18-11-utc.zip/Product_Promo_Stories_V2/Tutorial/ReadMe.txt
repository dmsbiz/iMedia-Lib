Hello!

Fonts in preview: 

Poppins: Regular (https://www.dafontfree.io/poppins-font-family/)

Bebas Neue: Bold (https://www.dafontfree.io/bebas-neue-font-family/)


Footages from (https://unsplash.com/ https://www.pexels.com/)

Music in preview: 
"Lo-fi Chill Vlog" (https://audiojungle.net/item/lofi-chill-vlog/39123060)

If you have any questions, please, send me massages on my mail: apeancovschi88@gmail.com
If you like this projects, rate please ( https://videohive.net/downloads )

My other projects (https://videohive.net/item/travel-instagram-stories/37849265)

Thank you.